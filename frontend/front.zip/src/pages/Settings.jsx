function ExecutionPreferencesSection() {
  const [timezone, setTimezone] = useState(
      () =>
          localStorage.getItem(
              'autoworkflow_pref_timezone'
          ) || 'UTC'
  )

  const [providers, setProviders] = useState([])
  const [defaultProvider, setDefaultProvider] = useState('auto')
  const [defaultModel, setDefaultModel] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    let mounted = true

    userService
        .getAiPreferences()
        .then((preferences) => {
          if (!mounted) return

          setProviders(
              Array.isArray(preferences?.providers)
                  ? preferences.providers
                  : []
          )

          setDefaultProvider(
              preferences?.provider || 'auto'
          )

          setDefaultModel(
              preferences?.model || ''
          )
        })
        .catch((err) => {
          if (!mounted) return

          toast.error(
              err?.response?.data?.message ||
              err?.message ||
              'Could not load AI preferences.'
          )
        })
        .finally(() => {
          if (mounted) {
            setLoading(false)
          }
        })

    return () => {
      mounted = false
    }
  }, [])

  const selectedProvider =
      providers.find(
          (provider) =>
              provider.key === defaultProvider
      )

  const availableModels =
      selectedProvider?.models || []

  const handleTimezoneChange = (value) => {
    setTimezone(value)

    localStorage.setItem(
        'autoworkflow_pref_timezone',
        value
    )
  }

  const saveAiPreference = async (
      provider,
      model
  ) => {
    setSaving(true)

    try {
      const updated =
          await userService.updateAiPreferences({
            provider,
            model:
                provider === 'auto'
                    ? null
                    : model,
          })

      setDefaultProvider(
          updated?.provider || provider
      )

      setDefaultModel(
          updated?.model || ''
      )

      if (
          Array.isArray(updated?.providers)
      ) {
        setProviders(updated.providers)
      }

      toast.success(
          'AI preferences updated.'
      )
    } catch (err) {
      toast.error(
          err?.response?.data?.message ||
          err?.message ||
          'Could not update AI preferences.'
      )
    } finally {
      setSaving(false)
    }
  }

  const handleProviderChange = (provider) => {
    if (provider === 'auto') {
      setDefaultProvider('auto')
      setDefaultModel('')

      saveAiPreference(
          'auto',
          null
      )

      return
    }

    const providerDefinition =
        providers.find(
            (item) =>
                item.key === provider
        )

    const firstModel =
        providerDefinition?.models?.[0] || ''

    setDefaultProvider(provider)
    setDefaultModel(firstModel)

    saveAiPreference(
        provider,
        firstModel
    )
  }

  const handleModelChange = (model) => {
    setDefaultModel(model)

    saveAiPreference(
        defaultProvider,
        model
    )
  }

  return (
      <SectionCard
          icon={Globe2}
          title="Execution Preferences"
          description="Defaults used by AutoWorkflow when an AI operation uses your account-level AI preference."
      >
        <div
            style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '12px',
            }}
        >
          <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '6px',
              }}
          >
            <label
                style={{
                  fontSize: '12px',
                  fontWeight: 600,
                  color: 'var(--text-secondary)',
                }}
            >
              Default Timezone
            </label>

            <select
                value={timezone}
                onChange={(e) =>
                    handleTimezoneChange(
                        e.target.value
                    )
                }
                style={inputStyle}
            >
              {[
                'UTC',
                'Asia/Kolkata',
                'America/New_York',
                'Europe/London',
              ].map((tz) => (
                  <option
                      key={tz}
                      value={tz}
                  >
                    {tz}
                  </option>
              ))}
            </select>
          </div>

          <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '6px',
              }}
          >
            <label
                style={{
                  fontSize: '12px',
                  fontWeight: 600,
                  color: 'var(--text-secondary)',
                }}
            >
              Default AI Provider
            </label>

            <select
                value={defaultProvider}
                onChange={(e) =>
                    handleProviderChange(
                        e.target.value
                    )
                }
                disabled={
                    loading || saving
                }
                style={inputStyle}
            >
              {providers.map(
                  (provider) => (
                      <option
                          key={provider.key}
                          value={provider.key}
                      >
                        {provider.label}
                      </option>
                  )
              )}
            </select>
          </div>

          <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '6px',
                gridColumn: '2',
              }}
          >
            <label
                style={{
                  fontSize: '12px',
                  fontWeight: 600,
                  color: 'var(--text-secondary)',
                }}
            >
              Default AI Model
            </label>

            {defaultProvider === 'auto' ? (
                <input
                    type="text"
                    value="Automatic"
                    readOnly
                    disabled
                    style={{
                      ...inputStyle,
                      opacity: 0.7,
                    }}
                />
            ) : (
                <select
                    value={defaultModel}
                    onChange={(e) =>
                        handleModelChange(
                            e.target.value
                        )
                    }
                    disabled={
                        loading ||
                        saving ||
                        availableModels.length === 0
                    }
                    style={inputStyle}
                >
                  {availableModels.map(
                      (model) => (
                          <option
                              key={model}
                              value={model}
                          >
                            {model}
                          </option>
                      )
                  )}
                </select>
            )}

            <span
                style={{
                  fontSize: '11px',
                  color: 'var(--text-muted)',
                }}
            >
            {defaultProvider === 'auto'
                ? 'Uses the configured provider fallback chain.'
                : 'This provider and model are used for account-level AI operations.'}
          </span>
          </div>
        </div>
      </SectionCard>
  )
}